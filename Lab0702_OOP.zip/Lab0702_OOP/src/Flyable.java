
public interface Flyable {
// สร้าง method Abstract
    public abstract void fly();
    
    public abstract void takeOff();
    
    public abstract void landing();
    
}
